---
title: "Português - Publications"
lang: pt
---

## Publicações

- Artigos científicos
- Ensaios e textos de mediação
- Composições musicais
- Códigos e software
