---
title: "Português - About"
lang: pt
---

## Sobre / CV

- CV académico
- CV musical
- Biografia

(Substitua pelo seu CV completo em Markdown ou anexe PDF.)
