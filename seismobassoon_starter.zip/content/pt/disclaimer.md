---
title: "Português - Disclaimer"
lang: pt
---

### Nota sobre idiomas

Apresento conteúdo em várias línguas. Minha proficiência varia; desculpe eventuais erros. Melhorarei as traduções com o tempo.
