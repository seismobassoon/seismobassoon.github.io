---
title: "Occitan - Disclaimer"
lang: oc
---

### Nota lingüistica

Presenti contengut en mai d'una lenga. Ma competéncia varia; perdonatz las errors. Melhorarai los elements amb lo temps.
