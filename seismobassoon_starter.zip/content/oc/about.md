---
title: "Occitan - About"
lang: oc
---

## A prepaus / CV

- CV academic
- CV musical
- Biografia

(Substituïtz amb vòstre CV complet en Markdown o adjuntatz un PDF.)
