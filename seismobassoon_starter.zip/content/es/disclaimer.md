---
title: "Español - Disclaimer"
lang: es
---

### Nota lingüística

Presento contenido en varios idiomas. Mi dominio varía; disculpa los errores. Mejoraré las traducciones con el tiempo.
