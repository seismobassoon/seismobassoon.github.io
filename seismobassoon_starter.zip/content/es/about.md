---
title: "Español - About"
lang: es
---

## Sobre / CV

- CV académico
- CV musical
- Biografía

(Sustituye con tu CV completo en Markdown o adjunta un PDF.)
