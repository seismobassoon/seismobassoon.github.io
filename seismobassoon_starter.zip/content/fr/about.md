---
title: "Français - About"
lang: fr
---

## À propos / CV

- CV académique
- CV musical
- Biographie

(Remplacez par votre CV complet en Markdown ou joignez un PDF.)
