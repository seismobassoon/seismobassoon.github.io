---
title: "Français - Disclaimer"
lang: fr
---

### Note linguistique

Je présente du contenu en plusieurs langues. Mon niveau varie; excusez les erreurs. J'améliorerai les traductions progressivement.
