---
title: "Italiano - Disclaimer"
lang: it
---

### Nota linguistica

Presento contenuti in diverse lingue. La mia competenza varia; scusa per gli errori. Migliorerò le traduzioni col tempo.
