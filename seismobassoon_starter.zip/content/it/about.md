---
title: "Italiano - About"
lang: it
---

## Informazioni / CV

- CV accademico
- CV musicale
- Biografia

(Sostituisci con il tuo CV in Markdown o allega un PDF.)
