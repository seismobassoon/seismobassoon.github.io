---
title: "Deutsch - Publications"
lang: de
---

## Publikationen

- Wissenschaftliche Artikel
- Essays und Vermittlungstexte
- Musikalische Kompositionen
- Codes und Software
