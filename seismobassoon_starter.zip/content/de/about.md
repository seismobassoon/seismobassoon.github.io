---
title: "Deutsch - About"
lang: de
---

## Über / CV

- Akademischer CV
- Musikalischer CV
- Biographie

(Ersetze durch dein vollständiges CV in Markdown oder hänge ein PDF an.)
