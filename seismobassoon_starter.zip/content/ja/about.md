---
title: "日本語 - About"
lang: ja
---

## アバウト / 履歴書

- 学術履歴
- 音楽履歴
- 伝記

(ここにMarkdownでCVを追加、またはPDFをリンクしてください)
